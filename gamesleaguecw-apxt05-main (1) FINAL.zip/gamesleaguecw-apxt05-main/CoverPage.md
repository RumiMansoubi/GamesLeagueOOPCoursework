ECM1410 Pair Programming Coursework

Please complete this coverpage and include in your submission:

Student 1 Candidate number: 

Student 2 Candidate number: 

Please write below a short statement detailing how you used GenAI tools to assist in your submission:


