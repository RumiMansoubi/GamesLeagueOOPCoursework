package gamesleague;

public class Game {
    
}
