package gamesleague;

public enum GameType {
    DICEROLL, 
    WORDMASTER;
}