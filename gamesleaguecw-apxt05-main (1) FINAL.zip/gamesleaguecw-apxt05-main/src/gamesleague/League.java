package gamesleague;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
//import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class League {
    private String name;
    private GameType gameType;
    private final List<Integer> players;
    private final List<Integer> invitedPlayers;
    private final List<String> invitedEmails;
    private final int id;
    private final int ownerId;
    private final int totalRounds;
    private int startDate;
    private int closeDate;
    private Status status;
    private Map<Integer, Map<Integer, String>> gameReports;
    private Map<Integer, int[]> dayScores;
    private Map<Integer, int[]> dayPoints;
    private Map<Integer, int[]> dayRankings;
    


    public League(int id, String name, int ownerId, GameType gameType) {
        this.name = name;
        this.id = id;
        this.ownerId = ownerId;
        this.invitedPlayers = new ArrayList<>();
        this.totalRounds = 0;
        this.invitedEmails = new ArrayList<>();
        this.status = Status.PENDING;
        this.startDate = -1;
        this.gameType = gameType;
        this.closeDate = -1;
        this.players = new ArrayList<>();
        this.gameReports = new HashMap<>();
        this.dayScores = new HashMap<>();
        this.dayPoints = new HashMap<>();
        this.dayRankings = new HashMap<>();




        players.add(ownerId);

    }

    public String getName() {
        return name;
    }

    @SuppressWarnings("CollectionsToArray")
    public String[] getEmailInvites() {
        return invitedEmails.toArray(new String[0]);
    }
    

    public void setName(String name) {
        this.name = name;
    }


    

    public int getOwnerId() {
        return ownerId;
    }

    public int getPlayerCount() {
        return players.size();
    }

    public int[] getPlayers() {
        return players.stream().mapToInt(Integer::intValue).toArray();
    }


    public void setPlayerInactive(int playerId) {
        players.remove(Integer.valueOf(playerId));
    }
 
    public void setPlayerActive(int playerId) {
        if (!players.contains(playerId)) {
            players.add(playerId);
        }
    }
    
    public int getId() {
        return id;
    }

    public int[] getPlayerInvites() {
        return invitedPlayers.stream().mapToInt(Integer::intValue).toArray();
    }

    public boolean hasPlayer(Player player) {
        return players.contains(null);
    }

    public boolean hasInvite(int playerId) {
        return invitedPlayers.contains(playerId);
    }

    public boolean hasInvite(String email) {
        return invitedEmails.contains(email);
    }
    

    public boolean isPlayerInLeague(int playerId) {
        return players.contains(playerId);
    }

    public boolean isPlayerActive(int playerId) {
        return players.contains(playerId);
    }    

    public void addPlayer(int playerId) {
        if (!players.contains(playerId)) {
            players.add(playerId);
        }
    }
    

    public void invitePlayer(int playerId) {
        if (!invitedPlayers.contains(playerId)) {
            invitedPlayers.add(playerId);
        }
    }
    

    public void invitePlayer(String email) {
        if (!invitedEmails.contains(email)) {
            invitedEmails.add(email);
        }
    }

    public void removeInvite(int playerId) {
        invitedPlayers.remove(Integer.valueOf(playerId));
    }

    public void removeInvite(String email) {
        invitedEmails.remove(email);
    }
    
    public void setStartDate(int day) {
        this.startDate = day;
        this.status = Status.IN_PROGRESS;
    }

    public int getStartDate() {
        return startDate;
    }

    public void setCloseDate(int day) {
        this.closeDate = day;
        this.status = Status.CLOSED;
    }

    public int getCloseDate() {
        return closeDate;
    }

    public void resetLeague() {
        this.status = Status.PENDING;
    }
    
    public GameType getGameType() {
        return gameType;
    }

    public void setGameType(GameType newGameType) {
        this.gameType = newGameType;
    }    

    public int getTotalRounds() {
        return totalRounds;
    }

    public Status getStatus() {
        return status;
    }

    public void setStatus(Status newStatus) {
        this.status = newStatus;
    }

    public int size() {
        throw new UnsupportedOperationException("Unimplemented method 'size'");
    }

    public void removeOwner(int playerId) {
        throw new UnsupportedOperationException("Unimplemented method 'removeOwner'");
    }

    public void addGameReport(int day, int playerId, String gameReport) {
        throw new UnsupportedOperationException("Not supported yet.");
    }



    public String getGameReport(int day, int playerId) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public void registerDayScores(int day, int[] scores) {
        dayScores.put(day,scores);

        throw new UnsupportedOperationException("Unimplemented method 'registerDayScores'");
    }

    public void voidDayPoints(int day) {
        int[] zeroPoints = new int[players.size()];
        Arrays.fill(zeroPoints, 0);
        dayPoints.put(day, zeroPoints);
        throw new UnsupportedOperationException("Unimplemented method 'voidDayPoints'");
    }

    public Status getDayStatus(int day) {
        if (!dayScores.containsKey(day)) {
            return Status.PENDING;
        }
        return Status.CLOSED;
        
    }

    public int[] getDayScores(int day) {
        return dayScores.getOrDefault(day, new int[players.size()]);

    }

    public int[] getDayRanking(int day) {
        return dayRankings.getOrDefault(day, new int[players.size()]);
        //throw new UnsupportedOperationException("Unimplemented method 'getDayRanking'");
    }

    public int[] getDayPoints(int day) {
        return dayPoints.getOrDefault(day, new int[players.size()]);
        //throw new UnsupportedOperationException("Unimplemented method 'getDayPoints'");
    }

    public Status getWeekStatus(int day) {
        return getDayStatus(day);
    }

    public int[] getWeekPoints(int day) {
        return getDayPoints(day);
    }

    public int[] getWeekRanking(int day) {
        return getDayRanking(day);
    }

    public Status getMonthStatus(int day) {
        return getDayStatus(day);
    }

    public int[] getMonthPoints(int day) {
        return getDayPoints(day);
    }

    public int[] getMonthRanking(int day) {
        return getDayRanking(day);
    }

    public Status getYearStatus(int day) {
        return getDayStatus(day);
    }

    public int[] getYearPoints(int day) {
        return getDayPoints(day);
    }

    public int[] getYearRanking(int day) {
        return getDayRanking(day);
    }

    public Map<Integer, Map<Integer, String>> getGameReports() {
        return gameReports;
    }

    public void setGameReports(Map<Integer, Map<Integer, String>> gameReports) {
        this.gameReports = gameReports;
    }

    public Map<Integer, int[]> getDayPoints() {
        return dayPoints;
    }

    public void setDayPoints(Map<Integer, int[]> dayPoints) {
        this.dayPoints = dayPoints;
    }

    public Map<Integer, int[]> getDayScores() {
        return dayScores;
    }

    public void setDayScores(Map<Integer, int[]> dayScores) {
        this.dayScores = dayScores;
    }

    public Map<Integer, int[]> getDayRankings() {
        return dayRankings;
    }

    public void setDayRankings(Map<Integer, int[]> dayRankings) {
        this.dayRankings = dayRankings;
    }

    public void addEmailInvite(String email) {
        
        throw new UnsupportedOperationException("Unimplemented method 'addEmailInvite'");
    }

    
    

}
